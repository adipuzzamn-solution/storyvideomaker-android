# StoryVideo Maker — Android MVP 0.1

A beginner-friendly native Android Studio starter project for a Bengali story-to-video app.

## Included now
- Bengali-first Android interface using Jetpack Compose
- Story text input and sample story
- Style selection (2D cartoon, 3D animation, realistic)
- Format selection (9:16 Shorts, 16:9 YouTube)
- On-device heuristic scene splitting and storyboard cards

## Not implemented yet
- AI story generation
- AI image generation
- AI image-to-video animation
- Text-to-speech / voiceover
- MP4 rendering and export

These features require additional integrations. AI generation may require an internet connection and a provider with a free tier; free availability and limits can change. Never put private API keys directly in an Android app.

## Open and run
1. Install Android Studio.
2. Choose **Open** and select this folder.
3. Let Gradle sync complete.
4. Run the `app` configuration on an Android device or emulator (Android 8.0 / API 26 or newer).

## Next implementation milestones
1. Add Android Photo Picker for assigning an image to each scene.
2. Add local slideshow MP4 export using Android MediaCodec/MediaMuxer.
3. Add Android TextToSpeech for local narration.
4. Optionally connect a hosted AI provider through a secure backend for story/image generation.

This is source code for a starter project, not a signed APK. Building the APK requires Android Studio/Android SDK.
