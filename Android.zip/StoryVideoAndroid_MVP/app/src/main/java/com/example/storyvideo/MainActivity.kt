package com.example.storyvideo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF211A35)
private val Purple = Color(0xFF7652E8)
private val Canvas = Color(0xFFF8F7FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StoryVideoApp() }
    }
}

@Composable
fun StoryVideoApp() {
    var story by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("2D কার্টুন") }
    var aspect by remember { mutableStateOf("9:16 Shorts") }
    var scenes by remember { mutableStateOf(listOf<String>()) }
    var showAbout by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple,
            background = Canvas,
            surface = Color.White,
            onBackground = Ink,
            onSurface = Ink
        )
    ) {
        Scaffold(containerColor = Canvas) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(48.dp).background(
                                Brush.linearGradient(listOf(Purple, Color(0xFFB58CF6))),
                                RoundedCornerShape(16.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Movie, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("গল্প থেকে ভিডিও", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text("AI Story-to-Video Maker • প্রাথমিক সংস্করণ", color = Color(0xFF716B80), fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Column(
                        Modifier.fillMaxWidth().background(
                            Brush.linearGradient(listOf(Color(0xFF292044), Color(0xFF5941A8))),
                            RoundedCornerShape(24.dp)
                        ).padding(20.dp)
                    ) {
                        Text("তোমার গল্প, তোমার সিনেমা ✨", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("একটি গল্প লিখে শুরু করো। সেটিকে দৃশ্যে ভাগ করে স্টোরিবোর্ড বানাও।", color = Color(0xFFE9E2FF), fontSize = 14.sp)
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFE3D6FF))
                            Spacer(Modifier.width(8.dp))
                            Text("প্রথম প্রোটোটাইপ • বিনামূল্যে পরীক্ষা", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    SectionTitle("১. গল্প লিখো", "গল্প নিজে লিখতে পারো, অথবা নমুনা দিয়ে শুরু করো")
                    OutlinedTextField(
                        value = story,
                        onValueChange = { story = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp),
                        placeholder = { Text("যেমন: এক ছোট্ট শিয়াল জাদুর বনে হারিয়ে যাওয়া পাখিটিকে বাড়ি ফিরতে সাহায্য করল...") },
                        shape = RoundedCornerShape(18.dp),
                        minLines = 5
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            story = "এক ছোট্ট শিয়াল জাদুর বনে একটি পথ হারানো পাখির দেখা পেল। শিয়ালটি পাখিটিকে সাহায্য করার সিদ্ধান্ত নিল। তারা ঝলমলে নদী পার হলো, উঁচু পাহাড়ে উঠল, আর শেষে পাখিটির নীড় খুঁজে পেল। পাখিটি খুশিতে গান গাইল, আর দুজনের মধ্যে দারুণ বন্ধুত্ব হলো।"
                        },
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("নমুনা গল্প ব্যবহার করো") }
                }
                item {
                    SectionTitle("২. ভিডিওর ধরন", "পছন্দ বেছে নাও")
                    Text("ইলাস্ট্রেশনের স্টাইল", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("2D কার্টুন", "3D অ্যানিমেশন", "বাস্তবধর্মী").forEach { option ->
                            FilterChip(selected = style == option, onClick = { style = option }, label = { Text(option) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("ভিডিও ফরম্যাট", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("9:16 Shorts", "16:9 YouTube").forEach { option ->
                            FilterChip(selected = aspect == option, onClick = { aspect = option }, label = { Text(option) })
                        }
                    }
                }
                item {
                    Button(
                        onClick = { scenes = splitIntoScenes(story) },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        enabled = story.trim().isNotEmpty()
                    ) {
                        Icon(Icons.Default.EditNote, null)
                        Spacer(Modifier.width(8.dp))
                        Text("গল্পকে দৃশ্যে ভাগ করো", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("নোট: এই প্রাথমিক সংস্করণে দৃশ্য ভাগ করা ফোনেই হয়; এটি এখনো AI-জেনারেটেড ছবি বা MP4 ভিডিও তৈরি করে না।", color = Color(0xFF777184), fontSize = 12.sp)
                }
                if (scenes.isNotEmpty()) {
                    item {
                        SectionTitle("৩. স্টোরিবোর্ড", "${scenes.size}টি দৃশ্য • $style • $aspect")
                    }
                    itemsIndexed(scenes) { index, scene ->
                        Row(
                            Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(14.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                Modifier.size(48.dp).background(Color(0xFFEDE7FF), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Image, null, tint = Purple, modifier = Modifier.size(25.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("দৃশ্য ${index + 1}", fontWeight = FontWeight.Bold, color = Purple)
                                Spacer(Modifier.height(5.dp))
                                Text(scene, fontSize = 14.sp, lineHeight = 21.sp)
                                Spacer(Modifier.height(6.dp))
                                Text("ছবির ধারণা: ${style} স্টাইলে ${scene.take(110)}", color = Color(0xFF777184), fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        OutlinedButton(
                            onClick = { showAbout = true },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(15.dp)
                        ) {
                            Icon(Icons.Default.Movie, null)
                            Spacer(Modifier.width(8.dp))
                            Text("ভিডিও তৈরির পরবর্তী ধাপ সম্পর্কে")
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(6.dp))
                    Text("পরবর্তী ধাপ: ছবির আপলোড/জেনারেশন, ভয়েসওভার এবং MP4 এক্সপোর্ট যোগ করা।", color = Color(0xFF777184), fontSize = 12.sp)
                    Text("StoryVideo Maker • MVP 0.1", color = Color(0xFF9A94A8), fontSize = 11.sp)
                }
            }
        }
        if (showAbout) {
            AlertDialog(
                onDismissRequest = { showAbout = false },
                title = { Text("ভিডিও এক্সপোর্ট") },
                text = { Text("পরবর্তী সংস্করণে প্রতিটি দৃশ্যের ছবি, বাংলা ভয়েসওভার, সাবটাইটেল ও মিউজিক একত্র করে MP4 ভিডিও সেভ করার সুবিধা যোগ করা হবে। AI ছবি/ভিডিও জেনারেশনের জন্য ফ্রি-লিমিটযুক্ত সার্ভিস বা নিজস্ব মডেল সংযুক্ত করতে হবে।") },
                confirmButton = { TextButton(onClick = { showAbout = false }) { Text("ঠিক আছে") } }
            )
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(subtitle, fontSize = 12.sp, color = Color(0xFF777184))
    }
}

private fun splitIntoScenes(input: String): List<String> {
    val normalized = input.trim().replace(Regex("\\s+"), " ")
    if (normalized.isBlank()) return emptyList()
    val sentences = normalized.split(Regex("(?<=[।!?])\\s+|(?<=\\.)\\s+"))
        .map { it.trim() }.filter { it.isNotBlank() }
    if (sentences.size <= 1) {
        return normalized.chunked(180).map { it.trim() }.filter { it.isNotEmpty() }
    }
    return sentences.chunked(2).map { it.joinToString(" ") }
}
