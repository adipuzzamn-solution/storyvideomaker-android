# StoryVideo Maker Android — MVP 0.3 (voiceover experiment)

## Included
- Bengali-first Jetpack Compose UI
- Story input and scene splitting
- Choose visual style and portrait/landscape output
- Assign photos to scenes using Android photo picker
- Bengali TTS preview and WAV narration synthesis using the phone's installed TTS engine
- Slideshow MP4 export with gentle zoom/pan, then attempts to mux narration audio into the MP4
- Saves the narrated MP4 to Movies/StoryVideoMaker

## Important limitations
- This is experimental source code, not a compiled APK. It has **not** been built or tested on a real device in this environment.
- The Android device's TTS engine must support Bengali (`bn-BD` or a compatible Bengali voice).
- Android builds vary in whether `MediaExtractor` can read the WAV output from TextToSpeech. If not supported, the app will show an error rather than a narrated video. The robust next step would be PCM-to-AAC encoding or a tested media library.
- The video is still a photo slideshow with pan/zoom; it does not generate AI images or animate characters.
- Narration is the full story while the slideshow timing remains about 3 seconds per scene, so narration and picture timing may not perfectly match.
- Video encoding itself uses device MediaCodec support and may need device-specific debugging.
- No paid API key is required for this experimental local workflow. Do not embed secret API keys in the app.

## Open in Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Unzip and open this folder in Android Studio.
3. Let Gradle sync.
4. Run on a physical Android device (Android 8.0/API 26+) or emulator.
5. Enter a story, split scenes, add an image to every scene, then tap **MP4 তৈরি ও সেভ করো**.
6. Ensure a Bengali voice is installed in Android Text-to-Speech settings.

If export fails, share the exact error shown in the app and the device/Android version; this source needs build/device validation before it can be called production-ready.
