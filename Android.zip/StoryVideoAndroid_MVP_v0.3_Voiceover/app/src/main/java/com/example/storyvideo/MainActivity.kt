package com.example.storyvideo

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

private val Ink = Color(0xFF211A35)
private val Purple = Color(0xFF7652E8)
private val CanvasBg = Color(0xFFF8F7FC)

data class Scene(val text: String, val imageUri: Uri? = null)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StoryVideoApp() }
    }
}

@Composable
fun StoryVideoApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var story by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("2D কার্টুন") }
    var aspect by remember { mutableStateOf("9:16 Shorts") }
    var scenes by remember { mutableStateOf(listOf<Scene>()) }
    var voiceStatus by remember { mutableStateOf("বাংলা ভয়েসের অবস্থা যাচাই করা হয়নি") }
    var isSpeaking by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf("গল্প লিখে শুরু করো") }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }

    DisposableEffect(context) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { result ->
            ttsReady = result == TextToSpeech.SUCCESS
            if (result == TextToSpeech.SUCCESS) {
                val languageResult = engine?.setLanguage(Locale("bn", "BD"))
                voiceStatus = when {
                    languageResult == TextToSpeech.LANG_MISSING_DATA ||
                    languageResult == TextToSpeech.LANG_NOT_SUPPORTED ->
                        "এই ফোনে বাংলা TTS ভয়েস নেই। Text-to-Speech সেটিংসে বাংলা ভয়েস ইনস্টল করে দেখো।"
                    else -> "বাংলা TTS পাওয়া গেছে (ফোনের ইঞ্জিন অনুযায়ী কণ্ঠ বদলাতে পারে)।"
                }
            } else {
                voiceStatus = "ফোনের Text-to-Speech ইঞ্জিন চালু করা যায়নি।"
            }
        }
        tts = engine
        onDispose {
            engine?.stop()
            engine?.shutdown()
            tts = null
        }
    }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && scenes.isNotEmpty()) {
            val target = scenes.indexOfFirst { it.imageUri == null }.let { if (it >= 0) it else 0 }
            scenes = scenes.mapIndexed { index, scene -> if (index == target) scene.copy(imageUri = uri) else scene }
            status = "দৃশ্য ${target + 1}-এ ছবি যোগ হয়েছে"
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = CanvasBg, surface = Color.White, onSurface = Ink)) {
        Scaffold(containerColor = CanvasBg) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Purple, Color(0xFFB58CF6))), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Movie, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("গল্প থেকে ভিডিও", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text("StoryVideo Maker • MVP 0.2", color = Color(0xFF716B80), fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF292044), Color(0xFF5941A8))), RoundedCornerShape(22.dp)).padding(18.dp)) {
                        Text("গল্পকে বানাও ছোট সিনেমা ✨", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("ছবি যোগ করো, বাংলা ভয়েস পরীক্ষা করো, আর মুভমেন্টসহ MP4 বানাও।", color = Color(0xFFE9E2FF), fontSize = 13.sp)
                    }
                }
                item {
                    SectionTitle("১. গল্প", "নিজের গল্প লেখো অথবা নমুনা নাও")
                    OutlinedTextField(
                        value = story, onValueChange = { story = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
                        placeholder = { Text("একটি ছোট্ট শিয়াল জাদুর বনে হারিয়ে যাওয়া পাখিটিকে বাড়ি ফিরতে সাহায্য করল...") },
                        shape = RoundedCornerShape(16.dp), minLines = 4
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        story = "এক ছোট্ট শিয়াল জাদুর বনে একটি পথ হারানো পাখির দেখা পেল। শিয়ালটি পাখিটিকে সাহায্য করার সিদ্ধান্ত নিল। তারা ঝলমলে নদী পার হলো, উঁচু পাহাড়ে উঠল, আর শেষে পাখিটির নীড় খুঁজে পেল। পাখিটি খুশিতে গান গাইল, আর দুজনের মধ্যে দারুণ বন্ধুত্ব হলো।"
                    }) { Text("নমুনা গল্প") }
                }
                item {
                    SectionTitle("২. ভিডিও সেটিংস", "ফরম্যাট ও ছবির স্টাইল")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("2D কার্টুন", "3D অ্যানিমেশন", "বাস্তবধর্মী").forEach {
                            FilterChip(selected = style == it, onClick = { style = it }, label = { Text(it, fontSize = 11.sp) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("9:16 Shorts", "16:9 YouTube").forEach {
                            FilterChip(selected = aspect == it, onClick = { aspect = it }, label = { Text(it, fontSize = 12.sp) })
                        }
                    }
                }
                item {
                    Button(
                        onClick = {
                            scenes = splitScenes(story).map { Scene(it) }
                            status = if (story.isBlank()) "আগে গল্প লেখো" else "দৃশ্য তৈরি হয়েছে। প্রতিটি দৃশ্যে ছবি যোগ করো।"
                        },
                        enabled = story.isNotBlank(), modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("গল্পকে দৃশ্যে ভাগ করো") }
                }
                if (scenes.isNotEmpty()) {
                    item { SectionTitle("৩. স্টোরিবোর্ড", "${scenes.size}টি দৃশ্য • ${style} • ${aspect}") }
                    itemsIndexed(scenes) { index, scene ->
                        Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("দৃশ্য ${index + 1}", fontWeight = FontWeight.Bold, color = Purple, modifier = Modifier.weight(1f))
                                Text(if (scene.imageUri == null) "ছবি নেই" else "ছবি যোগ হয়েছে", color = Color(0xFF777184), fontSize = 11.sp)
                            }
                            if (scene.imageUri != null) {
                                val bitmap = remember(scene.imageUri) { loadBitmap(context, scene.imageUri) }
                                if (bitmap != null) Image(bitmap.asImageBitmap(), null, modifier = Modifier.fillMaxWidth().height(150.dp))
                            }
                            Text(scene.text, fontSize = 14.sp, lineHeight = 21.sp)
                            OutlinedButton(onClick = { pickImage.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp))
                                Text(if (scene.imageUri == null) "গ্যালারি থেকে ছবি যোগ করো" else "ছবি বদলাও")
                            }
                        }
                    }
                    item {
                        Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("৪. বাংলা ভয়েসওভার", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(voiceStatus, color = Color(0xFF716B80), fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    val engine = tts
                                    if (!ttsReady || engine == null) {
                                        Toast.makeText(context, "Text-to-Speech ইঞ্জিন প্রস্তুত নয়", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val language = engine.setLanguage(Locale("bn", "BD"))
                                        if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
                                            Toast.makeText(context, "ফোনের TTS সেটিংসে বাংলা ভয়েস ইনস্টল করো", Toast.LENGTH_LONG).show()
                                        } else {
                                            engine.setSpeechRate(0.92f)
                                            engine.speak(story, TextToSpeech.QUEUE_FLUSH, null, "story-preview")
                                            isSpeaking = true
                                        }
                                    }
                                }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.PlayArrow, null); Text("শুনে দেখো") }
                                OutlinedButton(onClick = { tts?.stop(); isSpeaking = false }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Stop, null); Text("বন্ধ")
                                }
                            }
                            Text("ভয়েস ফোনের Text-to-Speech ইঞ্জিন থেকে আসে; বাংলা কণ্ঠ পাওয়া যাবে কি না তা ডিভাইসের ওপর নির্ভর করে।", color = Color(0xFF777184), fontSize = 11.sp)
                        }
                    }
                    item {
                        Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("৫. ভিডিও এক্সপোর্ট", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("ছবি + ধীর জুম/প্যান মুভমেন্ট এবং বাংলা ভয়েসওভার দিয়ে MP4 বানাও। সব দৃশ্যে ছবি থাকা দরকার।", color = Color(0xFF716B80), fontSize = 12.sp)
                            if (isExporting) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                            Button(
                                enabled = !isExporting && scenes.isNotEmpty() && scenes.all { it.imageUri != null },
                                onClick = {
                                    isExporting = true; progress = 0f; status = "ভিডিও তৈরি হচ্ছে…"
                                    scope.launch {
                                        try {
                                            val voiceEngine = tts ?: error("বাংলা TTS ইঞ্জিন প্রস্তুত নয়")
                                            val languageResult = voiceEngine.setLanguage(Locale("bn", "BD"))
                                            if (languageResult == TextToSpeech.LANG_MISSING_DATA ||
                                                languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                                                error("এই ফোনে বাংলা TTS নেই। Text-to-Speech সেটিংসে বাংলা ভয়েস ইনস্টল করো।")
                                            }
                                            voiceEngine.setSpeechRate(0.92f)
                                            val narrationFile = File(context.cacheDir, "narration_${System.currentTimeMillis()}.wav")
                                            synthesizeNarration(voiceEngine, story.ifBlank { scenes.joinToString(" ") { it.text } }, narrationFile)
                                            val silentUri = withContext(Dispatchers.IO) {
                                                exportVideo(context, scenes, aspect) { p -> scope.launch { progress = p * 0.85f } }
                                            }
                                            val silentFile = File(context.cacheDir, "silent_${System.currentTimeMillis()}.mp4")
                                            withContext(Dispatchers.IO) {
                                                context.contentResolver.openInputStream(silentUri)?.use { input ->
                                                    silentFile.outputStream().use { output -> input.copyTo(output) }
                                                } ?: error("তৈরি ভিডিও পড়া যায়নি")
                                            }
                                            val mixedFile = File(context.cacheDir, "narrated_${System.currentTimeMillis()}.mp4")
                                            try {
                                                withContext(Dispatchers.IO) { muxVideoWithNarration(silentFile, narrationFile, mixedFile) }
                                                withContext(Dispatchers.IO) {
                                                    context.contentResolver.delete(silentUri, null, null)
                                                    saveToGallery(context, mixedFile)
                                                }
                                            } finally {
                                                narrationFile.delete(); silentFile.delete(); mixedFile.delete()
                                            }
                                            progress = 1f
                                            status = "বাংলা ভয়েসসহ ভিডিও গ্যালারিতে সেভ হয়েছে"
                                            Toast.makeText(context, "বাংলা ভয়েসসহ ভিডিও সেভ হয়েছে", Toast.LENGTH_LONG).show()
                                        } catch (e: Exception) {
                                            status = "ভিডিও তৈরি হয়নি: ${e.message ?: "অজানা ত্রুটি"}"
                                            Toast.makeText(context, status, Toast.LENGTH_LONG).show()
                                        } finally { isExporting = false }
                                    }
                                }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp))
                                Text(if (isExporting) "ভিডিও তৈরি হচ্ছে…" else "MP4 তৈরি ও সেভ করো")
                            }
                            Text(status, color = Color(0xFF716B80), fontSize = 12.sp)
                            Text("বাংলা ভয়েসওভার WAV তৈরি করে ভিডিওর সঙ্গে মেশানোর চেষ্টা করা হয়। ডিভাইসের মিডিয়া ফরম্যাট সাপোর্টের ওপর নির্ভর করতে পারে।", color = Color(0xFF777184), fontSize = 11.sp)
                        }
                    }
                }
                item { Text("AI দিয়ে নতুন ছবি/গল্প তৈরি ও ছবিকে সত্যিকারের অ্যানিমেট করা পরের ধাপের ফিচার।", color = Color(0xFF777184), fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(subtitle, fontSize = 12.sp, color = Color(0xFF777184))
    }
}

private fun splitScenes(input: String): List<String> {
    val normalized = input.trim().replace(Regex("\\s+"), " ")
    if (normalized.isBlank()) return emptyList()
    val parts = normalized.split(Regex("(?<=[।!?])\\s+|(?<=\\.)\\s+")).filter { it.isNotBlank() }
    if (parts.size <= 1) return normalized.chunked(160).filter { it.isNotBlank() }
    return parts.chunked(2).map { it.joinToString(" ") }
}

private fun loadBitmap(context: Context, uri: Uri): Bitmap? =
    try { context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }

/**
 * Exports a silent H.264 MP4 slideshow with a gentle zoom/pan effect.
 * Uses MediaCodec + MediaMuxer; no third-party SDK or paid API required.
 */
/** Create a WAV narration file using the device's installed Android TTS engine. */
private suspend fun synthesizeNarration(engine: TextToSpeech, text: String, output: File) =
    suspendCancellableCoroutine<Unit> { continuation ->
        val utteranceId = "story-narration-${System.currentTimeMillis()}"
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == utteranceId && continuation.isActive) continuation.resume(Unit)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                if (id == utteranceId && continuation.isActive) continuation.resumeWith(
                    Result.failure(IllegalStateException("বাংলা ভয়েস ফাইল তৈরি করা যায়নি"))
                )
            }
            override fun onError(id: String?, errorCode: Int) {
                if (id == utteranceId && continuation.isActive) continuation.resumeWith(
                    Result.failure(IllegalStateException("বাংলা ভয়েস ফাইল তৈরি করা যায়নি (কোড $errorCode)"))
                )
            }
        })
        val result = engine.synthesizeToFile(text, Bundle(), output, utteranceId)
        if (result != TextToSpeech.SUCCESS && continuation.isActive) continuation.resumeWith(
            Result.failure(IllegalStateException("TTS অডিও তৈরি শুরু করা যায়নি"))
        )
        continuation.invokeOnCancellation { engine.stop() }
    }

/** Mux encoded video and synthesized WAV audio into a single MP4. */
private fun muxVideoWithNarration(videoFile: File, audioFile: File, outputFile: File) {
    val videoExtractor = MediaExtractor()
    val audioExtractor = MediaExtractor()
    var muxer: MediaMuxer? = null
    var muxerStarted = false
    try {
        videoExtractor.setDataSource(videoFile.absolutePath)
        audioExtractor.setDataSource(audioFile.absolutePath)
        var videoTrack = -1
        var audioTrack = -1
        for (i in 0 until videoExtractor.trackCount) {
            val f = videoExtractor.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                videoExtractor.selectTrack(i); videoTrack = i; break
            }
        }
        for (i in 0 until audioExtractor.trackCount) {
            val f = audioExtractor.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                audioExtractor.selectTrack(i); audioTrack = i; break
            }
        }
        if (videoTrack < 0) error("ভিডিও ট্র্যাক পাওয়া যায়নি")
        if (audioTrack < 0) error("এই ফোন WAV অডিও ট্র্যাক পড়তে পারেনি")
        muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val outVideo = muxer.addTrack(videoExtractor.getTrackFormat(videoTrack))
        val outAudio = muxer.addTrack(audioExtractor.getTrackFormat(audioTrack))
        muxer.start(); muxerStarted = true
        copyExtractorTrack(videoExtractor, muxer, outVideo)
        copyExtractorTrack(audioExtractor, muxer, outAudio)
        muxer.stop(); muxerStarted = false
    } finally {
        try { videoExtractor.release() } catch (_: Exception) {}
        try { audioExtractor.release() } catch (_: Exception) {}
        try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
    }
}

private fun copyExtractorTrack(extractor: MediaExtractor, muxer: MediaMuxer, trackIndex: Int) {
    val buffer = ByteBuffer.allocate(1 shl 20)
    val info = MediaCodec.BufferInfo()
    while (true) {
        buffer.clear()
        val size = extractor.readSampleData(buffer, 0)
        if (size < 0) break
        info.set(0, size, extractor.sampleTime.coerceAtLeast(0L), extractor.sampleFlags)
        muxer.writeSampleData(trackIndex, buffer, info)
        extractor.advance()
    }
}

private fun exportVideo(context: Context, scenes: List<Scene>, aspect: String, onProgress: (Float) -> Unit): Uri {
    val width = if (aspect.startsWith("9:16")) 540 else 960
    val height = if (aspect.startsWith("9:16")) 960 else 540
    val fps = 20
    val framesPerScene = fps * 3
    val totalFrames = framesPerScene * scenes.size
    val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
        setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        setInteger(MediaFormat.KEY_BIT_RATE, 2_000_000)
        setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
    }
    val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
    codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
    codec.start()
    val outputFile = File(context.cacheDir, "storyvideo_${System.currentTimeMillis()}.mp4")
    var muxer: MediaMuxer? = null
    var trackIndex = -1
    var muxerStarted = false
    val info = MediaCodec.BufferInfo()
    var frameIndex = 0
    try {
        muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val bitmaps = scenes.map { scene ->
            val uri = scene.imageUri ?: error("প্রতিটি দৃশ্যে ছবি যোগ করো")
            loadBitmap(context, uri) ?: error("একটি ছবি পড়া যায়নি")
        }
        while (frameIndex < totalFrames) {
            val inputIndex = codec.dequeueInputBuffer(10_000)
            if (inputIndex >= 0) {
                val inputBuffer = codec.getInputBuffer(inputIndex) ?: error("ভিডিও ইনপুট বাফার পাওয়া যায়নি")
                inputBuffer.clear()
                val sceneIndex = frameIndex / framesPerScene
                val localFrame = frameIndex % framesPerScene
                val source = bitmaps[sceneIndex]
                val frame = renderMotionFrame(source, width, height, localFrame, framesPerScene)
                val yuv = bitmapToI420(frame)
                if (yuv.size > inputBuffer.capacity()) error("ডিভাইসের ভিডিও বাফার ছোট")
                inputBuffer.put(yuv)
                val pts = frameIndex * 1_000_000L / fps
                codec.queueInputBuffer(inputIndex, 0, yuv.size, pts, 0)
                frame.recycle()
                frameIndex++
                onProgress(frameIndex.toFloat() / totalFrames)
            }
            drainEncoder(codec, info, muxer) { index, started ->
                if (index >= 0 && trackIndex < 0) trackIndex = index
                if (started) muxerStarted = true
            }
        }
        val inputIndex = codec.dequeueInputBuffer(10_000)
        if (inputIndex >= 0) codec.queueInputBuffer(inputIndex, 0, 0, totalFrames * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        var eos = false
        while (!eos) {
            val outIndex = codec.dequeueOutputBuffer(info, 10_000)
            when {
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (!muxerStarted) {
                        trackIndex = muxer.addTrack(codec.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                }
                outIndex >= 0 -> {
                    val out = codec.getOutputBuffer(outIndex)
                    if (info.size > 0 && out != null && muxerStarted) {
                        out.position(info.offset); out.limit(info.offset + info.size)
                        muxer.writeSampleData(trackIndex, out, info)
                    }
                    eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    codec.releaseOutputBuffer(outIndex, false)
                }
            }
        }
        bitmaps.forEach { it.recycle() }
        return saveToGallery(context, outputFile)
    } finally {
        try { codec.stop() } catch (_: Exception) {}
        try { codec.release() } catch (_: Exception) {}
        try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        outputFile.delete()
    }
}

private fun drainEncoder(
    codec: MediaCodec,
    info: MediaCodec.BufferInfo,
    muxer: MediaMuxer,
    state: (trackIndex: Int, started: Boolean) -> Unit
) {
    while (true) {
        val outIndex = codec.dequeueOutputBuffer(info, 0)
        when {
            outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> return
            outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                val track = muxer.addTrack(codec.outputFormat)
                muxer.start()
                state(track, true)
            }
            outIndex >= 0 -> {
                val buffer = codec.getOutputBuffer(outIndex)
                if (info.size > 0 && buffer != null) {
                    buffer.position(info.offset); buffer.limit(info.offset + info.size)
                    // Track index is captured by caller state; muxer writes on known track below is handled by state holder.
                    // Actual write uses muxer's first video track (0).
                    muxer.writeSampleData(0, buffer, info)
                }
                val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                codec.releaseOutputBuffer(outIndex, false)
                if (eos) return
            }
        }
    }
}

private fun renderMotionFrame(source: Bitmap, width: Int, height: Int, frame: Int, total: Int): Bitmap {
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(AndroidColor.BLACK)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    val progress = frame.toFloat() / max(1, total - 1)
    val zoom = 1.0f + 0.10f * progress
    val baseScale = max(width.toFloat() / source.width, height.toFloat() / source.height)
    val scaledW = source.width * baseScale * zoom
    val scaledH = source.height * baseScale * zoom
    val panX = (width - scaledW) * progress * 0.45f
    val panY = (height - scaledH) * (1f - progress) * 0.45f
    val dst = RectF(panX, panY, panX + scaledW, panY + scaledH)
    canvas.drawBitmap(source, null, dst, paint)
    return output
}

private fun bitmapToI420(bitmap: Bitmap): ByteArray {
    val width = bitmap.width
    val height = bitmap.height
    val argb = IntArray(width * height)
    bitmap.getPixels(argb, 0, width, 0, 0, width, height)
    val out = ByteArray(width * height * 3 / 2)
    var yIndex = 0
    var uIndex = width * height
    var vIndex = width * height + width * height / 4
    for (row in 0 until height) {
        for (col in 0 until width) {
            val c = argb[row * width + col]
            val r = AndroidColor.red(c); val g = AndroidColor.green(c); val b = AndroidColor.blue(c)
            val y = ((66*r + 129*g + 25*b + 128) shr 8) + 16
            val u = ((-38*r - 74*g + 112*b + 128) shr 8) + 128
            val v = ((112*r - 94*g - 18*b + 128) shr 8) + 128
            out[yIndex++] = y.coerceIn(0,255).toByte()
            if (row % 2 == 0 && col % 2 == 0) {
                out[uIndex++] = u.coerceIn(0,255).toByte()
                out[vIndex++] = v.coerceIn(0,255).toByte()
            }
        }
    }
    return out
}

private fun saveToGallery(context: Context, file: File): Uri {
    val resolver = context.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "StoryVideo_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/StoryVideoMaker")
    }
    val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: error("গ্যালারিতে ভিডিও সেভ করা যায়নি")
    try {
        resolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
            ?: error("ভিডিও ফাইল লেখা যায়নি")
    } catch (e: Exception) {
        resolver.delete(uri, null, null)
        throw e
    }
    return uri
}
