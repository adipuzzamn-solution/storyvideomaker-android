# StoryVideo Maker Android — MVP 0.2

## Included
- Bengali-first Jetpack Compose Android UI
- Story input and sample story
- Story splitting into storyboard scenes
- Choose 2D/3D/realistic style and portrait/landscape output
- Assign a photo to each scene using Android's system photo picker
- Bengali Text-to-Speech preview using the device's installed Android TTS engine
- Offline MP4 slideshow export using Android MediaCodec/MediaMuxer, with gentle zoom/pan movement
- Saves rendered MP4 to Movies/StoryVideoMaker in the device media library

## Honest limitations
- This does not generate new AI images or animate characters using a generative video model.
- The exported MP4 is a silent slideshow with zoom/pan motion. The voice is a separate preview in this version; it is not mixed into the MP4.
- Bengali TTS support depends on the voice engine installed on the phone.
- This is source code, not a prebuilt/signed APK. It has not been compiled or tested on a physical device in this environment.
- Video encoding support varies by device. Export uses 540x960 portrait or 960x540 landscape, 20 fps, about 3 seconds per scene.

## Open in Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder, or unzip the project first.
3. Let Gradle sync.
4. Run on a physical Android device (Android 8.0/API 26+) or emulator.
5. Enter a story, split scenes, add a photo to every scene, then choose **MP4 তৈরি ও সেভ করো**.
6. Use **শুনে দেখো** to preview narration. If Bengali is unavailable, install a Bengali voice in your device's Text-to-Speech settings.

## Free-first architecture
No external API key is required for the current local slideshow export and TTS preview. Generative AI story/image/video features can be connected later via a provider with a free tier or a secure backend. Do not embed secret API keys in the Android app.
